ToggleButtonEl = document.getElementsByClassName("Toggle-Button")[0]

const MenuLinksEl = document.getElementsByClassName("Menu-Links")[0]


ToggleButtonEl.addEventListener("click", ()=>
{
    MenuLinksEl.classList.toggle("active")
})