const loginForm = document.querySelector(".login-form")
 async function getUserData(obj)
 {
     let {uname, pwd} = obj

     try{
let response = await axios.get(`http://localhost:3000/api/getuser?username=${uname}&password=${pwd}`)
let data = response.data

//construct a query string
 const UserDataQueryString = new URLSearchParams(data).toString()
console.log(UserDataQueryString)
let baseURL = "profile.html?"
window.location.href=baseURL+UserDataQueryString 

    }
    catch(error)
    {
console.log('Failed to receive user data')
    }
}

loginForm.addEventListener("submit", (event) => {
event.preventDefault()
     const fd = new FormData(loginForm)
     const UserDataObjectLgn = Object.fromEntries(fd)
     getUserData(UserDataObjectLgn)

})

