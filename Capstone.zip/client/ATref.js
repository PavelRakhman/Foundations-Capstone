//Array with Questions. The arrais of objects. Each object has two properties: the question itself and an array of answers. Each answer is an object with two properties--the text and status(correct or incorrect)
let counter =0
const questions =[
    {question: "What is the past due balance threshold for Guided Path programs?",
    answers: [{text: "$2,000", correct:false}, {text: "$1,500", correct:false}, {text:"$2,500", correct: true}]},
    {question: "In a Graduate Guided Path program, half-time enrollment is ...",
    answers: [{text: "3-4 credit hours", correct:true}, {text: "5 credit hours", correct:false}, {text:"6+ credit hours", correct: false}]},
    {question: "In an Undergraduate Guided Path program, half-time level of enrollment is ...",
    answers: [{text: "6-9 credit hours", correct: true}, {text: "3-4 credit hours", correct:false}, {text:"12+ credit hours", correct: false}]},
    {question: "In a Graduate Guied Path program, full-time enrollment is ...",
    answers: [{text: "3-4 credit hours", correct:false}, {text: "5 credit hours", correct:false}, {text:"6+ credit hours", correct: true}]},
    {question: "In an Undergraduate Guided Path Program, full-time enrollment is ...",
    answers: [{text: "10 credit hours", correct:false}, {text: "6 credit hours", correct: false}, {text:"12+ credit hours", correct: true}]},
    {question: "In Guided Path, what charges is the learner responsible for if they drop the course between day one and day 5?",
    answers: [{text: "All charges for the dropped course are reversed", correct: true}, {text: "25% of the tuition + Resource Kit Fee", correct:false}, {text:"75% of the tuition + Resource Kit Fee", correct: false}]},
    {question: "In Guided Path, what charges is the learner responsible for if they drop the course between day six and day twelve?",
    answers: [{text: "25% of the tuition + Resource Kit Fee", correct: true}, {text: "75% of the tuition + Resource Kit Fee", correct: false}, {text:"All charges", correct: false}]},
    {question: "In Guided Path, what charges is the learner responsible for if they drop the course after day twelve?",
    answers: [{text: "75% of all charges", correct:false}, {text: "25% of the tuition + Resource Kit Fee", correct:false}, {text:"100% of the tuition + Resource Kit Fee", correct: true}]},
    {question: "When is FASAP run in Guided Path?",
    answers: [{text: "During the third week of each quarter", correct:false}, {text: "on the first day of the quarter", correct:false}, {text:"At the end of each quarter", correct: true}]},
    {question: "In Guided Path, a past due balance exceeding $2,500 will result in ..",
    answers: [{text: "A hold on the account on Tuesday before the start of the next quarter", correct: true}, {text: "Nothing", correct: false}, {text:"Immediate placement of hold on the account", correct: false}]},
    
    {question: "How are direct costs calculated in Guided Path?",
    answers: [{text: "Learners are charged the same amount per quarter minus discounts", correct:false}, {text: "Number of credit hours times tuition per credit hour) plus Resource Kit Fee minus discounts", correct: true}, {text:"TDirect costs per quarter = (Cost of attendance /  4) - discounts ", correct: false}]}
    ]
let scoreIndicatorEl = document.querySelector(".scoreIndicator")
let testStatiscticsEl = document.querySelector(".TestStatisctics")
//the two variables below hav an initial status of undefined
let shuffledQuestions, currentQuestionIndex


//these variables store Start and next buttons buttons
const StartBtn = document.getElementById("start-btn")
const nextBtn = document.getElementById("next-btn")

const questionBody = document.getElementById("question")
const answerButtonsElement = document.getElementById("answer-buttons")
const questionBox = document.getElementById("question-container")

StartBtn.addEventListener("click", ()=>{StartGame()})

nextBtn.addEventListener("click", ()=>{
    currentQuestionIndex ++
    setNextQuestion()
})

function StartGame()
{
    scoreIndicatorEl.innerHTML = "Current score: "
    testStatiscticsEl.innerHTML = null
console.log("Started")
StartBtn.classList.add("hide")

shuffledQuestions = questions.sort(()=>{Math.random() -0.5}) //this is where we shuffle our array of questions
currentQuestionIndex =0
questionBox.classList.remove("hide") //the question container appears on teh screen
setNextQuestion()
}

function setNextQuestion()
{
resetState()
ShowQuestion(shuffledQuestions[currentQuestionIndex])
}


function resetState()
{
    nextBtn.classList.add("hide")

    while(answerButtonsElement.firstChild)
    {
        answerButtonsElement.removeChild(answerButtonsElement.firstChild)
    }
}

function ClearStatusClass(element)
{
    element.classList.remove("right")
    element.classList.remove("wrong")
}

function ShowQuestion(question)
{
    questionBody.innerText = question.question
    question.answers.forEach(answer=>{
        const button = document.createElement('button')
        button.innerText = answer.text
        button.classList.add('btn')

        if (answer.correct)
        {
            button.dataset.correct = answer.correct
            
        }
        button.addEventListener("click", selectAnswer)
        answerButtonsElement.appendChild(button)
    })
}

function setStatusClass(element, correct)
{
ClearStatusClass(element)
if (correct)
{
   
element.classList.add('right')

}    
else{
    element.classList.add('wrong')
}

}

function selectAnswer(e)
{
    const SelectedButton = e.target
    const correct = SelectedButton.dataset.correct
    if (SelectedButton.dataset.correct)
    {
        counter +=1
        scoreIndicatorEl.innerHTML = "Current score: " + counter + "out of " +  (questions.length -1)
        console.log(counter)
    }
    setStatusClass(document.body,correct)
Array.from(answerButtonsElement.children).forEach(button => 
    {
        setStatusClass(button, button.dataset.correct)
    })

    if (shuffledQuestions.length > currentQuestionIndex + 1)
    {
        nextBtn.classList.remove("hide")
    }
    else
    {
        testStatiscticsEl.innerHTML = "Test results sent to the server. We are working on adding them to the data base"
        StartBtn.innerText = "Restart"
    StartBtn.classList.remove("hide")
    updateTestScore()    
    }
}

 function updateTestScore(testScore)
 {
    let params = new URL(window.location.href).searchParams
    let uname = params.get("username")
axios
.put(`http://localhost:5000/api/newscore`,{score: counter, username: uname})    
.then((response)=>{console.log(response.data)})
.catch((error)=>{console.log('Error updating the score')}) 

 }