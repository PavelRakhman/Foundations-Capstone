

const regFormEl = document.querySelector(".registrationForm")

const responseSection = document.querySelector(".responseSection")

regFormEl.addEventListener("submit", (event)=>{
    event.preventDefault()
    responseSection.innerHTML = null
    //Form input values are stored in a javascript object
const FD = new FormData(regFormEl)
const NewUserObject = Object.fromEntries(FD)

axios
.post(`http://localhost:3000/api/addNewUser`, NewUserObject)
.then((response)=>{
    const data = response.data
    console.log(data)
const p = document.createElement('p')
const t = document.createTextNode('User added to the database')
p.appendChild(t)
responseSection.appendChild(p)
responseSection.style.display ="flex"
})
.catch((error)=>{console.log('Could not add the user to the data base')})


    

})