const Sequelize = require('sequelize')
const {DataTypes} = Sequelize




//database operations


function connectDatabase(dbData)
{
const ORMInstance = new Sequelize(dbData.DATABASE, dbData.USER, dbData.PASSWORD,{
    port: dbData.PORT,
    host: dbData.HOST,
    dialect: dbData.DIALECT
})
return ORMInstance    
}






module.exports = {connectDatabase}




//test 
const dbconfig = require('../config/db-config')

const ORMInstance = connectDatabase(dbconfig)
const testUserData={
    fname:'Alana',
    lname:'John',
    dept: 'FAST',
    uname:'jalana',
    pwd:'ADS123!',
    score:0
}

// ORMInstance.authenticate()
// .then(()=>{console.log('Connected to the database successfully')
// })
// .catch((error)=>{console.log('Error connecting to the database')})
const {fname, lname, dept, uname, pwd} = testUserData

const Model = ORMInstance.define(uname,
    {user_id:{type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true, allowNull:false},
    first_name:{type: DataTypes.STRING, allowNull:false},
last_name:{type: DataTypes.STRING, allowNull:false},
department:{type: DataTypes.STRING, allowNull:false},
username:{type: DataTypes.STRING, allowNull:false},
password:{type: DataTypes.STRING, allowNull:false},
score: {type: DataTypes.INTEGER, allowNull:false}
}, {freezeTableName:true, timestamps:false})

//Syncing the newly defined model
// Model.sync()
// .then(()=>{

// })
// .catch((error)=>{
// console.log('Error syncing with the database')    
// })