module.exports = {
    DATABASE:'testapp',
    USER:'prwdev',
    PASSWORD: 'CromFeyr198862!',
    HOST:'test.c2v1o5gvmivs.us-east-2.rds.amazonaws.com',
    PORT:3306,
    DIALECT:'mysql'
}


