const Sequelize = require('sequelize');
const {DataTypes} = Sequelize
const express=require('express')
const cors = require('cors')
const app = express()
app.use(express.json())
app.use(cors())

const dataBaseOperations = require('../controller/controller')
const dbData = require('../config/db-config')



const ORMInstance = dataBaseOperations.connectDatabase(dbData)

ORMInstance.authenticate()
.then(()=>{console.log('Connected to the database')})
.catch((error)=>{console.log('Error connecting to the database')})
//Endpoints

app.post('/api/addNewUser', (req, res)=>{
    let UserData = Object.assign(req.body)
    //create and synchronize a model
const {fname, lname, dept, uname, pwd} = UserData
res.status(200).send('Here is the data we received from the client:' + UserData)
const Model = ORMInstance.define(uname,
    {
        user_id:{type: DataTypes.INTEGER, primaryKey:true, allowNull:false, autoIncrement: true},
        first_name:{type: DataTypes.STRING, allowNull:false},
        last_name:{type: DataTypes.STRING, allowNull:false},
        department: {type: DataTypes.STRING, allowNull:false},
        username: {type: DataTypes.STRING, allowNull:false},
        password: {type: DataTypes.STRING, allowNull:false},
        score:{type: DataTypes.INTEGER, allowNull:false, defaultValue:0}
},{freezeTableName:true, autoIncrement:true, timeStamps: false})
//Syncing the model and assigning values to the fields.
Model.sync({alter:true})
.then(()=>{console.log('Syncing successful')
const newProfile = Model.build({
    first_name:fname,
    last_name:lname,
    department:dept,
    username:uname,
    password:pwd,
    score:0
})
newProfile.save()
})
.catch((error)=>{console.log('Error syncing with the database')})
})


app.get('/api/getuser', (req, res)=>{
let username = req.query.username

const Model = ORMInstance.define(username,
    {
        user_id:{type: DataTypes.INTEGER, primaryKey:true, allowNull:false, autoIncrement: true},
        first_name:{type: DataTypes.STRING, allowNull:false},
        last_name:{type: DataTypes.STRING, allowNull:false},
        department: {type: DataTypes.STRING, allowNull:false},
        username: {type: DataTypes.STRING, allowNull:false},
        password: {type: DataTypes.STRING, allowNull:false},
        score:{type: DataTypes.INTEGER, allowNull:false, defaultValue:0}
},{freezeTableName:true, autoIncrement:true, timeStamps: false})

Model.sync({alter:true})
.then(()=>{
return Model.findAll()
.then((data)=>{
    const UserDataArray = JSON.parse(JSON.stringify(data))
    res.status(200).send(UserDataArray[0])
})    

})
.catch((error)=>{console.log('Error syncing with the database')})


    
})


app.put('/api/newscore', (req, res)=>{
    res.status(200).send('The app will save and update results. We are working on it')
})





app.delete('/api/delprofile', (req, res)=>{
    let tableName = req.query.username
    const Model = ORMInstance.define(tableName,
        {
            user_id:{type: DataTypes.INTEGER, primaryKey:true, allowNull:false, autoIncrement: true},
            first_name:{type: DataTypes.STRING, allowNull:false},
            last_name:{type: DataTypes.STRING, allowNull:false},
            department: {type: DataTypes.STRING, allowNull:false},
            username: {type: DataTypes.STRING, allowNull:false},
            password: {type: DataTypes.STRING, allowNull:false},
            score:{type: DataTypes.INTEGER, allowNull:false, defaultValue:0}
    },{freezeTableName:true, autoIncrement:true, timeStamps: false})

    Model.sync({alter:true})
    .then(()=>{
        return Model.drop()
        .then(()=>{console.log('Table dropped')
    res.status(200).send('User profile has been deleted')})
        .catch((error)=>{console.log('Error dropping the table')})
    })
    .catch((error)=>{console.log('Error syncing with the database')})


})


app.listen(3000, ()=>{console.log('Server started')})    